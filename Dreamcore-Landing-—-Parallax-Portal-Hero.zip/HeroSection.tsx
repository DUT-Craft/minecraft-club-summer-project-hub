"use client";

import { useState } from "react";

const stats = [
  { label: "公开项目", value: "12" },
  { label: "公开想法", value: "28" },
  { label: "加入口", value: "12" },
];

const plazaItems = [
  {
    kind: "project",
    tag: "项目 · 招募中",
    title: "暑假建筑共创",
    desc: "用于展示已审核项目，卡片可承载封面、标签、申请入口和负责人。",
    meta: ["负责人：米洛", "3 个申请"],
  },
  {
    kind: "idea",
    tag: "想法 · 待组队",
    title: "红石机关挑战",
    desc: "玩法灵感入口强调轻量提交，适合学生创作者快速发起讨论。",
    meta: ["贡献者：星野", "8 条回应"],
  },
  {
    kind: "join",
    tag: "申请 · 处理中",
    title: "加入申请看板",
    desc: "管理员和项目发起人可以继续进入后台处理审核与成员加入。",
    meta: ["待处理", "12 个入口"],
  },
];

const filters = [
  { label: "全部", value: "all" },
  { label: "项目", value: "project" },
  { label: "想法", value: "idea" },
  { label: "申请", value: "join" },
] as const;

export function HeroSection() {
  const [open, setOpen] = useState(false);
  const [toast, setToast] = useState("");
  const [activeFilter, setActiveFilter] = useState<(typeof filters)[number]["value"]>("all");

  const visibleItems = plazaItems.filter((item) => activeFilter === "all" || item.kind === activeFilter);

  function showToast(message: string) {
    setToast(message);
    window.setTimeout(() => setToast(""), 2200);
  }

  return (
    <section className="relative overflow-hidden bg-[#eff9ff] text-[#20301f]">
      <div className="pointer-events-none absolute inset-0 bg-[linear-gradient(rgba(255,255,255,.35)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,.32)_1px,transparent_1px)] bg-[length:22px_22px]" />
      <header className="relative z-10 mx-auto flex w-[min(1180px,calc(100%_-_32px))] items-center justify-between gap-4 py-4">
        <a href="#" className="flex items-center gap-2.5 font-black">
          <span className="relative h-[38px] w-[38px] rounded-[7px] border-2 border-[#382617] bg-[linear-gradient(180deg,#75c64a_0_42%,#8d5a32_42%_100%)] shadow-[4px_4px_0_rgba(56,38,23,.24)]" />
          <span className="text-[19px]">猫娘社</span>
        </a>
        <nav className="flex items-center gap-2 rounded-[10px] border-2 border-[#38261738] bg-[#fffdf4c2] p-1.5 shadow-[0_5px_0_rgba(56,38,23,.10)]">
          {["首页", "投稿", "后台"].map((item) => (
            <button
              key={item}
              type="button"
              onClick={() => {
                if (item === "投稿") setOpen(true);
                if (item === "后台") showToast("后台入口需要登录后进入");
              }}
              className="min-h-[38px] rounded-[8px] border-2 border-transparent px-3 text-sm font-extrabold text-[#2f442a] transition hover:-translate-y-0.5 hover:border-[#38261759] hover:bg-[#fff7ce]"
            >
              {item}
            </button>
          ))}
        </nav>
      </header>

      <div className="relative z-10 mx-auto grid min-h-[calc(100svh-118px)] w-[min(1180px,calc(100%_-_32px))] grid-cols-1 items-center gap-8 py-9 lg:grid-cols-[0.94fr_1.06fr] lg:gap-14">
        <div className="max-w-[580px]">
          <div className="mb-5 inline-flex items-center gap-2 rounded-[8px] border-2 border-[#382617] bg-[#fff3bc] px-2.5 py-1.5 font-mono text-[13px] font-black text-[#5b431d] shadow-[4px_4px_0_rgba(56,38,23,.16)]">
            <span className="h-3 w-3 rotate-45 border-2 border-[#382617] bg-[#83d5ff]" />
            暑假共创 · 审核后公开展示
          </div>
          <h1 className="max-w-[9.5em] text-balance text-[clamp(40px,6vw,76px)] font-black leading-[.98] tracking-normal">
            Minecraft 暑假共创项目广场
          </h1>
          <p className="mt-5 max-w-[560px] text-pretty text-[clamp(16px,1.75vw,19px)] font-semibold leading-[1.72] text-[#40563a]">
            集中展示社团项目、收集玩法灵感、处理加入申请。公开内容由管理员审核后展示。
          </p>

          <div className="mt-7 grid gap-3 sm:flex sm:flex-wrap">
            <button
              type="button"
              onClick={() => setOpen(true)}
              className="min-h-[50px] rounded-[8px] border-2 border-[#382617] bg-[linear-gradient(180deg,#93d65a,#55a63a)] px-5 font-black shadow-[6px_6px_0_rgba(56,38,23,.22)] transition hover:-translate-x-0.5 hover:-translate-y-0.5"
            >
              投稿项目
            </button>
            <a
              href="#ideas"
              className="inline-flex min-h-[50px] items-center justify-center rounded-[8px] border-2 border-[#382617] bg-[linear-gradient(180deg,#fff7d0,#e6c986)] px-5 font-black shadow-[6px_6px_0_rgba(56,38,23,.22)] transition hover:-translate-x-0.5 hover:-translate-y-0.5"
            >
              查看想法
            </a>
          </div>

          <div className="mt-7 grid gap-2.5 sm:grid-cols-3">
            {stats.map((stat) => (
              <article
                key={stat.label}
                className="min-h-[96px] rounded-[8px] border-2 border-[#382617] bg-[linear-gradient(135deg,#fff8d6,#ead394)] p-3 shadow-[5px_5px_0_rgba(56,38,23,.18)]"
              >
                <div className="font-mono text-[30px] font-black leading-none tabular-nums">{stat.value}</div>
                <div className="mt-2.5 text-[13px] font-black text-[#5d4b2a]">{stat.label}</div>
              </article>
            ))}
          </div>
        </div>

        <figure className="relative rounded-[12px] border-2 border-[#382617] bg-[#bde9ff] shadow-[12px_12px_0_rgba(56,38,23,.20)]">
          <img
            src="/assets/hero-voxel-plaza.png"
            alt="原创像素方块世界插画：草地方块、木牌、工作台、矿石、火把、书本和学生创作者正在搭建项目广场"
            className="aspect-[16/10] w-full rounded-[10px] object-cover"
          />
          <figcaption className="absolute inset-x-4 bottom-4 flex items-center justify-between gap-3 rounded-[8px] border-2 border-[#3826178c] bg-[#fff8dcea] px-3 py-2 text-[13px] font-black text-[#4b321b] shadow-[4px_4px_0_rgba(56,38,23,.18)]">
            公告板正在更新 · 暑假共创招募中
            <span className="h-2.5 w-2.5 border-2 border-[#382617] bg-[#d4472d]" />
          </figcaption>
        </figure>
      </div>

      <section id="ideas" className="relative z-10 mx-auto w-[min(1180px,calc(100%_-_32px))] pb-16">
        <div className="rounded-[12px] border-2 border-[#382617] bg-[#fffdf4e0] p-4 shadow-[8px_8px_0_rgba(56,38,23,.14)]">
          <div className="mb-3.5 flex flex-col gap-3 md:flex-row md:items-center md:justify-between">
            <div>
              <h2 className="text-[21px] font-black">项目广场</h2>
              <p className="mt-1 text-[13px] font-extrabold text-[#5d6b55]">
                首屏下沿露出项目列表，提示这里是可继续浏览的社区广场。
              </p>
            </div>
            <div className="flex flex-wrap gap-2" role="tablist" aria-label="项目广场筛选">
              {filters.map((filter) => (
                <button
                  key={filter.value}
                  type="button"
                  role="tab"
                  aria-selected={activeFilter === filter.value}
                  onClick={() => setActiveFilter(filter.value)}
                  className={`min-h-[34px] rounded-[8px] border-2 px-2.5 text-sm font-black shadow-[3px_3px_0_rgba(56,38,23,.10)] ${
                    activeFilter === filter.value
                      ? "border-[#382617] bg-[#e9ffd4] text-[#2f6f2d]"
                      : "border-[#3826176b] bg-[#fff7d0] text-[#3c4d35]"
                  }`}
                >
                  {filter.label}
                </button>
              ))}
            </div>
          </div>
          <div className="grid gap-3 md:grid-cols-3" role="tabpanel" aria-live="polite">
            {visibleItems.map((item) => (
              <article
                key={item.kind}
                className="min-h-[118px] rounded-[8px] border-2 border-[#382617b3] bg-[#fff8dc] p-3 shadow-[4px_4px_0_rgba(56,38,23,.12)]"
              >
                <span className="inline-flex min-h-6 items-center rounded-[6px] border-2 border-[#38261747] bg-[#e9ffd4] px-2 text-xs font-black text-[#35682b]">
                  {item.tag}
                </span>
                <h3 className="mt-3 text-base font-black leading-tight">{item.title}</h3>
                <p className="mt-2 text-[13px] font-semibold leading-relaxed text-[#5f6b58]">{item.desc}</p>
                <div className="mt-3 flex justify-between gap-2 border-t-2 border-dashed border-[#3826172e] pt-2.5 text-xs font-black text-[#6a5839]">
                  <span>{item.meta[0]}</span>
                  <span>{item.meta[1]}</span>
                </div>
              </article>
            ))}
          </div>
        </div>
      </section>

      {open && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-[#1f2d196b] p-5" role="dialog" aria-modal="true" aria-labelledby="submit-title">
          <form
            className="w-full max-w-[520px] rounded-[12px] border-2 border-[#382617] bg-[#fffdf4] p-5 shadow-[12px_12px_0_rgba(56,38,23,.28)]"
            onSubmit={(event) => {
              event.preventDefault();
              setOpen(false);
              showToast("已保存为待审核草稿");
            }}
          >
            <div className="mb-4 flex items-center justify-between gap-4">
              <h2 id="submit-title" className="text-[22px] font-black">投稿项目</h2>
              <button type="button" aria-label="关闭投稿弹层" onClick={() => setOpen(false)} className="h-9 w-9 rounded-[8px] border-2 border-[#382617] bg-[#fff0b5] font-black">
                ×
              </button>
            </div>
            <label className="grid gap-1.5 text-[13px] font-black text-[#3c4d35]">
              项目名称
              <input required className="rounded-[8px] border-2 border-[#382617b3] bg-[#fff8dc] px-3 py-2.5 outline-none" placeholder="例如：暑假建筑共创" />
            </label>
            <label className="mt-3 grid gap-1.5 text-[13px] font-black text-[#3c4d35]">
              简短说明
              <textarea required className="min-h-[92px] rounded-[8px] border-2 border-[#382617b3] bg-[#fff8dc] px-3 py-2.5 outline-none" placeholder="说明项目目标、需要的成员、当前进度…" />
            </label>
            <div className="mt-4 flex justify-end gap-2.5">
              <button type="button" onClick={() => setOpen(false)} className="rounded-[8px] border-2 border-[#382617] bg-[#fff7d0] px-4 py-2 font-black">
                稍后再写
              </button>
              <button type="submit" className="rounded-[8px] border-2 border-[#382617] bg-[#55a63a] px-4 py-2 font-black">
                提交审核
              </button>
            </div>
          </form>
        </div>
      )}
      <div
        className={`fixed bottom-6 left-1/2 z-[60] -translate-x-1/2 rounded-[8px] border-2 border-[#382617] bg-[#e9ffd4] px-3.5 py-2.5 font-black shadow-[6px_6px_0_rgba(56,38,23,.18)] transition ${
          toast ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
        }`}
        aria-live="polite"
      >
        {toast}
      </div>
    </section>
  );
}
